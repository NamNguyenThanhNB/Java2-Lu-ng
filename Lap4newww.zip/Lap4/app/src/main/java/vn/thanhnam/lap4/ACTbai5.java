package vn.thanhnam.lap4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ACTbai5 extends AppCompatActivity {
    private TextView textView;
    private Toolbar toolbar4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai5);
        toolbar4 = findViewById(R.id.toolbar4);
        textView = findViewById(R.id.textView);

        toolbar4.setTitle("Bài 5");
        setSupportActionBar(toolbar4);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public void openPopUpMenu(View view) {

        PopupMenu popupMenu = new PopupMenu(this, textView);
        popupMenu.getMenuInflater().inflate(R.menu.my_menu_b5, popupMenu.getMenu());

        popupMenu.show();
    }
}
