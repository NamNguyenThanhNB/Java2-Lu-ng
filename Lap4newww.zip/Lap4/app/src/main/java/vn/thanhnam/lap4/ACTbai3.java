package vn.thanhnam.lap4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;

public class ACTbai3 extends AppCompatActivity {
private Toolbar toolbar2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai3);

        toolbar2=findViewById(R.id.toolbar2);
        toolbar2.setTitle("Bài 3");
        setSupportActionBar(toolbar2);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu_b1,menu);

        return super.onCreateOptionsMenu(menu);
    }
}
