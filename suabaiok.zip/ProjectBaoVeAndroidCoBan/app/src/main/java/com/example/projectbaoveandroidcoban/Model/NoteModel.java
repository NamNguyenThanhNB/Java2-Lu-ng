package com.example.projectbaoveandroidcoban.Model;

public class NoteModel {
    public String tieuDe, noiDung, thoiGian;
    public int id;


}
