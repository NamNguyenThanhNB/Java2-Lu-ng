package com.example.projectbaoveandroidcoban.SQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.projectbaoveandroidcoban.Model.NoteModel;

import java.util.ArrayList;
import java.util.List;

import static com.example.projectbaoveandroidcoban.SQLite.ReadSQLite.C_CONTENT;
import static com.example.projectbaoveandroidcoban.SQLite.ReadSQLite.C_DATE;
import static com.example.projectbaoveandroidcoban.SQLite.ReadSQLite.C_ID;
import static com.example.projectbaoveandroidcoban.SQLite.ReadSQLite.C_TITLE;
import static com.example.projectbaoveandroidcoban.SQLite.ReadSQLite.T_NAME;

public class DAO {

    private ReadSQLite readSQLite;

    public DAO(Context context) {
        readSQLite = new ReadSQLite(context);
    }


    // INSERT -------------------------------------
    public long insertSQLite(NoteModel noteModel) {

        SQLiteDatabase sqLiteDatabase = readSQLite.getWritableDatabase();


        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, noteModel.id);
        contentValues.put(C_TITLE, noteModel.tieuDe);
        contentValues.put(C_CONTENT, noteModel.noiDung);
        contentValues.put(C_DATE, noteModel.thoiGian);



        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);


        sqLiteDatabase.close();

        return result;
    }

    // UPDATE -------------------------------------
    public long updateSQLite(NoteModel noteModel) {

        SQLiteDatabase sqLiteDatabase = readSQLite.getWritableDatabase();


        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, noteModel.id);
        contentValues.put(C_TITLE, noteModel.tieuDe);
        contentValues.put(C_CONTENT, noteModel.noiDung);
        contentValues.put(C_DATE, noteModel.thoiGian);


        long result = sqLiteDatabase.update(T_NAME, contentValues, C_ID + "=?", new String[]{String.valueOf(noteModel.id)});


        sqLiteDatabase.close();

        return result;
    }

    // DELETE -------------------------------------
    public int deleteSQLite(int id) {
        SQLiteDatabase sqLiteDatabase = readSQLite.getWritableDatabase();

        int result = sqLiteDatabase.delete(T_NAME, C_ID + "=?", new String[]{String.valueOf(id)});

        sqLiteDatabase.close();

        return result;
    }


    // GETALL -------------------------------------

    public List<NoteModel> getAllSQLite() {
        List<NoteModel> carList = new ArrayList<>();



        SQLiteDatabase sqLiteDatabase = readSQLite.getReadableDatabase();

        String SELECT = "SELECT * FROM " + T_NAME;

        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                NoteModel noteModel = new NoteModel();
                noteModel.id = Integer.parseInt(cursor.getString(0));
                noteModel.tieuDe = cursor.getString(1);
                noteModel.noiDung = cursor.getString(2);
                noteModel.thoiGian = cursor.getString(3);

                carList.add(noteModel);
            } while (cursor.moveToNext());
        }

        sqLiteDatabase.close();

        return carList;
    }


}
