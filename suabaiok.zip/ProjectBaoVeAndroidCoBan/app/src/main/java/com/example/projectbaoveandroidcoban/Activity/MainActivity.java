package com.example.projectbaoveandroidcoban.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.projectbaoveandroidcoban.R;

public class MainActivity extends AppCompatActivity {

    private Button btnThemVao;
    private Button btnListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnThemVao = findViewById(R.id.btnThemVao);
        btnListView = findViewById(R.id.btnListView);
    }

    public void themVao(View view) {
        Intent intent = new Intent(MainActivity.this, SubThemVao.class);
        startActivity(intent);

    }

    public void listView(View view) {
        Intent intent = new Intent(MainActivity.this, SubListView.class);
        startActivity(intent);


    }
}
