package com.example.projectbaoveandroidcoban.SQLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ReadSQLite extends SQLiteOpenHelper {


    public ReadSQLite(Context context) {
        super(context, "abSQLite.db", null, 1);
    }

    public final static String T_NAME = "NoteTable";
    public final static String C_ID = "id";
    public final static String C_TITLE = "tieuDe";
    public final static String C_CONTENT = "noiDung";
    public final static String C_DATE = "thoiGian";

    public final static String CREATE_TABLE = "CREATE TABLE NoteTable (id INTEGER PRIMARY KEY, tieuDe NVARCHAR, thoiGian VARCHAR,noiDung VARCHAR)";


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
