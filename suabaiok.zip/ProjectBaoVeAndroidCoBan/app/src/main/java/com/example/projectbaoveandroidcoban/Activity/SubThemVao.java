package com.example.projectbaoveandroidcoban.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projectbaoveandroidcoban.Model.NoteModel;
import com.example.projectbaoveandroidcoban.R;
import com.example.projectbaoveandroidcoban.SQLite.DAO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SubThemVao extends AppCompatActivity {

    private EditText edtMaTieuDe;
    private EditText edtTenTieuDe;
    private EditText edtNoiDung;
    private EditText edtThoiGian;

    private DAO dao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_them_vao);
        edtMaTieuDe = findViewById(R.id.edtMaTieuDe);
        edtTenTieuDe = findViewById(R.id.edtTenTieuDe);
        edtNoiDung = findViewById(R.id.edtNoiDung);
        edtThoiGian = findViewById(R.id.edtThoiGian);

        dao= new DAO(SubThemVao.this);

    }

    public void Them(View view) {
        try {
            if (edtMaTieuDe.getText().toString().trim().equals("")) {
                Toast.makeText(this, "MA TIEU DE DANG TRONG ", Toast.LENGTH_SHORT).show();
                edtMaTieuDe.requestFocus();
                return;
            } else if (edtTenTieuDe.getText().toString().trim().equals("")) {
                Toast.makeText(this, "TEN TIEU DE DANG TRONG", Toast.LENGTH_SHORT).show();
                edtTenTieuDe.requestFocus();
                return;
            } else if (edtNoiDung.getText().toString().trim().equals("")) {
                Toast.makeText(this, "NOI DUNG DANG TRONG", Toast.LENGTH_SHORT).show();
                edtNoiDung.requestFocus();
                return;
            } else if (edtThoiGian.getText().toString().trim().equals("")) {
                Toast.makeText(this, "THOI GIANG DANG RONG", Toast.LENGTH_SHORT).show();
                edtThoiGian.requestFocus();
                return;
            } else {
                List<NoteModel> noteModels = new ArrayList<>();
                NoteModel noteModel = new NoteModel();
                noteModel.id = Integer.parseInt(edtMaTieuDe.getText().toString().trim());
                noteModel.tieuDe = edtTenTieuDe.getText().toString().trim();
                noteModel.noiDung = edtNoiDung.getText().toString().trim();
                noteModel.thoiGian = edtThoiGian.getText().toString().trim();

                noteModels.add(noteModel);


//                for (int i = 0; i < noteModels.size(); i++) {
//                    if (edtMaTieuDe.getText().toString().trim().equals(noteModels.get(i).id)) {
//                        Toast.makeText(this, "MA TIEU DE DA TRUNG", Toast.LENGTH_SHORT).show();
//                        return;
//                    }
//                }

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                try {
                    Date thoiGian = dateFormat.parse(edtThoiGian.getText().toString());
                }catch (Exception e){
                    Toast.makeText(this, "NHAP DUNG DINH DANG THOI GIAN dd/MM/yyyy", Toast.LENGTH_SHORT).show();
                    return;
                }

                 long result = dao.insertSQLite(noteModel);



                if (result > 0) {
                    Toast.makeText(this, "DA THEM THANH CONG", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "THEM THAT BAI", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "VUI LONG NHAP DUNG THHONG TIN", Toast.LENGTH_SHORT).show();
        }


    }
}
