package com.example.projectbaoveandroidcoban.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.projectbaoveandroidcoban.R;

public class SubListView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_list_view);
    }
}
