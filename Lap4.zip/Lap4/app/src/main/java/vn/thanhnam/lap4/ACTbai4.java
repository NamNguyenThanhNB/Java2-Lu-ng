package vn.thanhnam.lap4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ACTbai4 extends AppCompatActivity {
private Toolbar toolbar3;

private ListView lvList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai4);
        toolbar3=findViewById(R.id.toolbar3);

        lvList=findViewById(R.id.lvList);
        String food[] = {"Chicken", "Bef", "Fruit", "Orange", "Lemon", "Apple", "Cherry", "StrawBerry",
                "Bean", "Snack", "Potato", "Sweet Potato", "Soup", "Tofu", "Mango", "Fish", "Vegetable"};

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,android.R.layout.select_dialog_item,food);
        registerForContextMenu(lvList);
        lvList.setAdapter(arrayAdapter);

        toolbar3.setTitle("Bài 4");
        setSupportActionBar(toolbar3);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.my_menu_b4,menu);


    }
}
