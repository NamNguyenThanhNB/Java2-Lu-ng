package vn.thanhnam.lap4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;

public class ACTbai1 extends AppCompatActivity {
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai1);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");

        toolbar.setNavigationIcon(R.drawable.ic_notifications_black_24dp);
        toolbar.setLogo(R.drawable.ic_home_black_24dp);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu_b1, menu);
        return super.onCreateOptionsMenu(menu);
    }
}
