package vn.thanhnam.quanlithuchi.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.thanhnam.quanlithuchi.model.ThuChi;

import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.tc_id;
import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.tc_khoanThuChi;
import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.tc_loaiThuChi;
import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.tc_ten;
import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.tc_tien;
import static vn.thanhnam.quanlithuchi.sqlite.ThuChiSQLite.thuChi_Table;

public class ThuChiDAO {

    private ThuChiSQLite thuChiSQLite;


    public ThuChiDAO(Context context) {
        thuChiSQLite = new ThuChiSQLite(context);
    }

    public long insertTC(ThuChi thuChi) {


        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getWritableDatabase();

        //gep cap dl
        ContentValues contentValues = new ContentValues();
        contentValues.put(tc_ten, thuChi.tc_ten);
        contentValues.put(tc_tien, thuChi.tc_tien);
        contentValues.put(tc_khoanThuChi, thuChi.tc_khoanThuChi);
        contentValues.put(tc_loaiThuChi, thuChi.tc_loaiThuChi);


        //insert_kt
        long result = sqLiteDatabase.insert(thuChi_Table, null, contentValues);
        //dong ket noi
        sqLiteDatabase.close();
        return result;
    }

    public long updateTC(ThuChi thuChi) {


        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getWritableDatabase();

        //gep cap dl
        ContentValues contentValues = new ContentValues();
        contentValues.put(tc_ten, thuChi.tc_ten);
        contentValues.put(tc_tien, thuChi.tc_tien);
        contentValues.put(tc_khoanThuChi, thuChi.tc_khoanThuChi);
        contentValues.put(tc_loaiThuChi, thuChi.tc_loaiThuChi);


        //insert_kt
        long result = sqLiteDatabase.update(thuChi_Table, contentValues, tc_id + "=?", new String[]{String.valueOf(thuChi.tc_id)});
        //dong ket noi
        sqLiteDatabase.close();
        return result;
    }

    public long deleteTC(int id) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getWritableDatabase();
        long result = sqLiteDatabase.delete(thuChi_Table, tc_id + "=?",
                new String[]{String.valueOf(id)});
        sqLiteDatabase.close();
        return result;
    }

    public List<ThuChi> getAllTC() {
        List<ThuChi> thuChiList = new ArrayList<>();

        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getReadableDatabase();

        //viet cau lenh select
        String SELECT = "SELECT * FROM " + thuChi_Table;

        //sd rawQuery
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {

                ThuChi thuChi = new ThuChi();
                thuChi.tc_id = cursor.getInt(0);
                thuChi.tc_ten = cursor.getString(1);
                thuChi.tc_tien = cursor.getFloat(2);
                thuChi.tc_khoanThuChi = cursor.getString(3);
                thuChi.tc_loaiThuChi = cursor.getString(4);

                thuChiList.add(thuChi);
            } while (cursor.moveToNext());
            // dong ket noi con tro
            cursor.close();
        }

        // dong ket noi DB
        sqLiteDatabase.close();
        return thuChiList;
    }


    public List<ThuChi> getAll_TC_THU() {
        List<ThuChi> thuChiList = new ArrayList<>();

        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getReadableDatabase();

        //viet cau lenh select
        String SELECT = "SELECT * FROM " + thuChi_Table +
                " WHERE " + tc_khoanThuChi + " = 'THU'";

        //sd rawQuery
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {

                ThuChi thuChi = new ThuChi();
                thuChi.tc_id = cursor.getInt(0);
                thuChi.tc_ten = cursor.getString(1);
                thuChi.tc_tien = cursor.getFloat(2);
                thuChi.tc_khoanThuChi = cursor.getString(3);
                thuChi.tc_loaiThuChi = cursor.getString(4);

                thuChiList.add(thuChi);
            } while (cursor.moveToNext());
            // dong ket noi con tro
            cursor.close();
        }

        // dong ket noi DB
        sqLiteDatabase.close();
        return thuChiList;
    }

    public List<ThuChi> getAll_TC_CHI() {
        List<ThuChi> thuChiList = new ArrayList<>();

        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getReadableDatabase();

        //viet cau lenh select
        String SELECT = "SELECT * FROM " + thuChi_Table +
                " WHERE " + tc_khoanThuChi + " = 'CHI'";

        //sd rawQuery
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {

                ThuChi thuChi = new ThuChi();
                thuChi.tc_id = cursor.getInt(0);
                thuChi.tc_ten = cursor.getString(1);
                thuChi.tc_tien = cursor.getFloat(2);
                thuChi.tc_khoanThuChi = cursor.getString(3);
                thuChi.tc_loaiThuChi = cursor.getString(4);

                thuChiList.add(thuChi);
            } while (cursor.moveToNext());
            // dong ket noi con tro
            cursor.close();
        }

        // dong ket noi DB
        sqLiteDatabase.close();
        return thuChiList;
    }

    public double sumTC() {

        //xin quyen
        SQLiteDatabase sqLiteDatabase = thuChiSQLite.getReadableDatabase();

        //viet cau lenh select
        String SELECT = "SELECT SUM( " + tc_tien + " )AS 'TONG' FROM " + thuChi_Table + " WHERE " + tc_khoanThuChi + "= 'THU'";


        //sd rawQuery
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);

        double sum = cursor.getDouble(0);
        cursor.close();
        return sum;
    }
}
