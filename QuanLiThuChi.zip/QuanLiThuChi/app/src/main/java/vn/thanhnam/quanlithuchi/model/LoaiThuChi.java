package vn.thanhnam.quanlithuchi.model;

public class LoaiThuChi {

    public int ltc_id;

    public String ltc_ten;


    public static final String LCHI = "CHI";
    public static final String LTHU = "THU";
    public String ltc_loaiThuChi;

}
