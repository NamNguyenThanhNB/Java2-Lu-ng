package vn.thanhnam.quanlithuchi.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.thanhnam.quanlithuchi.R;
import vn.thanhnam.quanlithuchi.adapter.LoaiThuAdapter;
import vn.thanhnam.quanlithuchi.model.LoaiThuChi;
import vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiDAO;


public class LoaiThu_FR extends Fragment {

    private RecyclerView rvList;
    private ImageView imgDialog;
    private LoaiThuChiDAO loaiThuChiDAO;
    private LoaiThuAdapter loaiThuAdapter;
    List<LoaiThuChi> loaiThuChiList;
    private boolean check;
    private int id = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.loaithu_fr, container, false);
        rvList = root.findViewById(R.id.rvLoaiThu);
        imgDialog = root.findViewById(R.id.imgDialog_LT);


        loaiThuChiDAO = new LoaiThuChiDAO(getActivity());
        loaiThuChiList = loaiThuChiDAO.getAllLTC();
        loaiThuAdapter = new LoaiThuAdapter(getActivity(), loaiThuChiList, rvList);

        //kb layout manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rvList.setLayoutManager(linearLayoutManager);
        rvList.setAdapter(loaiThuAdapter);

        imgDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                View viewKT = LayoutInflater.from(getActivity()).inflate(R.layout.insert_lt, null);
                builder.setView(viewKT);

                final AlertDialog alertDialog = builder.show();
                final TextView btnNO = alertDialog.findViewById(R.id.btnNO_LT);
                final TextView btnYES = alertDialog.findViewById(R.id.btnYES_LT);

                final EditText edtName = alertDialog.findViewById(R.id.edtName_LT);


                btnNO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });

                btnYES.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        check = true;
                        final String name = edtName.getText().toString().trim();
                        if (name.equals("")) {
                            edtName.setError("Loại thu không được để trống");
                            edtName.requestFocus();
                            check = false;
                            return;
                        }

                        if (check == true) {
                            LoaiThuChi loaiThuChi = new LoaiThuChi();
                            loaiThuChi.ltc_id = id;
                            id++;
                            loaiThuChi.ltc_ten = name;
                            loaiThuChi.ltc_loaiThuChi = loaiThuChi.LTHU;
                            long result = loaiThuChiDAO.insertLTC(loaiThuChi);
                            if (result < 0) {
                                Toast.makeText(getActivity(), "Thêm mới không thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e("1: ", loaiThuChi.ltc_id + "");
                                alertDialog.dismiss();
                                loaiThuChiList = loaiThuChiDAO.getAllLTC();
                                loaiThuAdapter = new LoaiThuAdapter(getActivity(), loaiThuChiList, rvList);
                                //kb layout manager
                                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
                                rvList.setLayoutManager(linearLayoutManager);
                                rvList.setAdapter(loaiThuAdapter);
                            }
                        }
                    }
                });
            }
        });
        return root;
    }
}

