package vn.thanhnam.quanlithuchi.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.List;

import vn.thanhnam.quanlithuchi.R;
import vn.thanhnam.quanlithuchi.model.ThuChi;
import vn.thanhnam.quanlithuchi.sqlite.ThuChiDAO;

public class ThongKeFragment extends Fragment {

    private TextView tvSumTHU, tvSumCHI, tvSD;
    private Button btnShow;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fr_thongke, container, false);

        tvSumTHU = view.findViewById(R.id.tvSumTHU);
        tvSumCHI = view.findViewById(R.id.tvSumCHI);
        tvSD = view.findViewById(R.id.tvSD);
        btnShow = view.findViewById(R.id.btnShow);

        ThuChiDAO thuChiDAO = new ThuChiDAO(getActivity());
        List<ThuChi> thuList = thuChiDAO.getAll_TC_THU();
        int lengthThu = thuList.size();
        double sumThu = 0;
        for (int i = 0; i < lengthThu; i++) {
            sumThu += thuList.get(i).tc_tien;
        }

        List<ThuChi> chiList = thuChiDAO.getAll_TC_CHI();
        int lengthChi = chiList.size();
        double sumChi = 0;
        for (int i = 0; i < lengthChi; i++) {
            sumChi += chiList.get(i).tc_tien;
        }


        tvSumTHU.setText("Tổng số tiền thu được là: " + sumThu);
        tvSumCHI.setText("Tổng số tiền bạn đã chi là: " + sumChi);

        final double finalSumThu = sumThu;
        final double finalSumChi = sumChi;
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double thongke = finalSumThu - finalSumChi;
                if (thongke < 0) {
                    tvSD.setText("Bạn đã bị âm: " + (-thongke));
                } else {
                    tvSD.setText("Số dư của bạn là: " + thongke);
                }
            }
        });
        return view;
    }
}
