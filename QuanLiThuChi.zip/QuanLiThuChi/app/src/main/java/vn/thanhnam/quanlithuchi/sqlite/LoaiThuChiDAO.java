package vn.thanhnam.quanlithuchi.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.thanhnam.quanlithuchi.model.LoaiThuChi;

import static vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiSQLite.loaithuchi_Table;
import static vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiSQLite.ltc_id;
import static vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiSQLite.ltc_loaiThuChi;
import static vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiSQLite.ltc_ten;

public class LoaiThuChiDAO {
    private LoaiThuChiSQLite loaiThuChiSQLite;

    public LoaiThuChiDAO(Context context) {
        loaiThuChiSQLite = new LoaiThuChiSQLite(context);
    }

    public long insertLTC(LoaiThuChi loaiThuChi) {


        //xin quyen
        SQLiteDatabase sqLiteDatabase = loaiThuChiSQLite.getWritableDatabase();

        //gep cap dl
        ContentValues contentValues = new ContentValues();
        contentValues.put(ltc_ten, loaiThuChi.ltc_ten);
        contentValues.put(ltc_loaiThuChi, loaiThuChi.ltc_loaiThuChi);


        //insert_kt
        long result = sqLiteDatabase.insert(loaithuchi_Table, null, contentValues);
        //dong ket noi
        sqLiteDatabase.close();
        return result;
    }

    public long updateLTC(LoaiThuChi loaiThuChi) {


        //xin quyen
        SQLiteDatabase sqLiteDatabase = loaiThuChiSQLite.getWritableDatabase();

        //gep cap dl
        ContentValues contentValues = new ContentValues();
        contentValues.put(ltc_ten, loaiThuChi.ltc_ten);
        contentValues.put(ltc_loaiThuChi, loaiThuChi.ltc_loaiThuChi);


        //insert_kt
        long result = sqLiteDatabase.update(loaithuchi_Table, contentValues, ltc_id + "=?", new String[]{String.valueOf(loaiThuChi.ltc_id)});
        //dong ket noi
        sqLiteDatabase.close();
        return result;
    }

    public long deleteLTC(int id) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = loaiThuChiSQLite.getWritableDatabase();
        long result = sqLiteDatabase.delete(loaithuchi_Table, ltc_id + "=?",
                new String[]{String.valueOf(id)});
        sqLiteDatabase.close();
        return result;
    }

    public List<LoaiThuChi> getAllLTC() {
        List<LoaiThuChi> loaiThuChiList = new ArrayList<>();

        //xin quyen
        SQLiteDatabase sqLiteDatabase = loaiThuChiSQLite.getReadableDatabase();

        //viet cau lenh select
        String SELECT = "SELECT * FROM " + loaithuchi_Table;

        //sd rawQuery
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {

                LoaiThuChi loaiThuChi = new LoaiThuChi();
                loaiThuChi.ltc_id = cursor.getInt(0);
                loaiThuChi.ltc_ten = cursor.getString(1);
                loaiThuChi.ltc_loaiThuChi = cursor.getString(2);

                loaiThuChiList.add(loaiThuChi);
            } while (cursor.moveToNext());
            // dong ket noi con tro
            cursor.close();
        }

        // dong ket noi DB
        sqLiteDatabase.close();
        return loaiThuChiList;
    }

}
