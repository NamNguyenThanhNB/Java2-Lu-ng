package vn.thanhnam.quanlithuchi.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoaiThuChiSQLite extends SQLiteOpenHelper {

    public static final String ltc_id = "id";

    public static final String ltc_ten = "ten";
    public static final String ltc_loaiThuChi = "ltc";

    public static final String loaithuchi_Table = "loaiThuChi";
    public static final String taobangLoaiThuChi =
            "Create table loaiThuChi (id integer primary key autoincrement," +
                    "ten NVARCHAR,ltc NVARCHAR)";

    public LoaiThuChiSQLite(Context context) {
        super(context, "loaithuchiSQLite06.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(taobangLoaiThuChi);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
