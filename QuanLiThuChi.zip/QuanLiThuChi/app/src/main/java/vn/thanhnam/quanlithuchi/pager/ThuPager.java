package vn.thanhnam.quanlithuchi.pager;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import vn.thanhnam.quanlithuchi.fragment.KhoanThu_FR;
import vn.thanhnam.quanlithuchi.fragment.LoaiThu_FR;

public class ThuPager extends FragmentStatePagerAdapter {
    public ThuPager(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            KhoanThu_FR khoanThuFragment = new KhoanThu_FR();
            return khoanThuFragment;
        } else {
            LoaiThu_FR loaiThuFragment = new LoaiThu_FR();
            return loaiThuFragment;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return "KHOẢN THU";
        } else {
            return "LOẠI THU";
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
}
