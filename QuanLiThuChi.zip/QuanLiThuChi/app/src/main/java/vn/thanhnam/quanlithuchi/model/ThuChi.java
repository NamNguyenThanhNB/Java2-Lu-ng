package vn.thanhnam.quanlithuchi.model;

public class ThuChi {


    public static final String CHI = "CHI";
    public static final String THU = "THU";


    public int tc_id;

    public String tc_ten;

    public float tc_tien;


    public String tc_khoanThuChi;

    public String tc_loaiThuChi;

}
