package vn.thanhnam.quanlithuchi.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.thanhnam.quanlithuchi.R;
import vn.thanhnam.quanlithuchi.model.ThuChi;
import vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiDAO;
import vn.thanhnam.quanlithuchi.sqlite.ThuChiDAO;

public class KhoanChiAdapter extends RecyclerView.Adapter<KhoanThuHolder> {

    private Context context;
    private List<ThuChi> khoanChiDataList;
    boolean check;
    private RecyclerView rvList;
    private ThuChiDAO khoanThuDAO;
    private KhoanChiAdapter khoanChiAdapter;


    public KhoanChiAdapter(Context context, List<ThuChi> khoanChiDataList, RecyclerView rvList) {
        this.context = context;
        this.khoanChiDataList = khoanChiDataList;
        this.rvList = rvList;
    }

    @NonNull
    @Override
    public KhoanThuHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout._rv, parent, false);
        KhoanThuHolder khoanThuHolder = new KhoanThuHolder(view);
        return khoanThuHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final KhoanThuHolder holder, final int position) {

        khoanThuDAO = new ThuChiDAO(context);
        holder.tvName.setText(khoanThuDAO.getAllTC().get(position).tc_ten);

        holder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder_info = new AlertDialog.Builder(context);
                View view_info = LayoutInflater.from(context).inflate(R.layout._info, null);
                builder_info.setView(view_info);
                final AlertDialog alertDialog_info = builder_info.show();

                final TextView tvLoai_info = alertDialog_info.findViewById(R.id.tvLoai_info);
                final TextView tvName_info = alertDialog_info.findViewById(R.id.tvName_info);
                final TextView tvLTC_info = alertDialog_info.findViewById(R.id.tvLTC_info);
                final TextView tvMoney_info = alertDialog_info.findViewById(R.id.tvMoney_info);

                tvName_info.setText(khoanThuDAO.getAllTC().get(position).tc_ten);

                tvLoai_info.setText("Loại: " + khoanThuDAO.getAllTC().get(position).tc_khoanThuChi);
                tvMoney_info.setText("Số tiền: " + khoanThuDAO.getAllTC().get(position).tc_tien);
                tvLTC_info.setText("Khoản chi: " + khoanThuDAO.getAllTC().get(position).tc_loaiThuChi);
            }
        });
        holder.imgINS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "UPDATE", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View viewKT = LayoutInflater.from(context).inflate(R.layout.insert_kt, null);
                builder.setView(viewKT);

                final AlertDialog alertDialog = builder.show();
                final TextView btnNO = alertDialog.findViewById(R.id.btnNO_KT);
                final TextView btnYES = alertDialog.findViewById(R.id.btnYES_KT);

                final EditText edtName = alertDialog.findViewById(R.id.edtName_KT);
                final EditText edtLTC = alertDialog.findViewById(R.id.edtLTC_KT);
                final EditText edtMoney = alertDialog.findViewById(R.id.edtMoney_KT);

                btnNO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });

                btnYES.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        check = true;
                        final String name = edtName.getText().toString().trim();
                        final String ltc = edtLTC.getText().toString().trim();
                        final String money = edtMoney.getText().toString().trim();
                        if (name.equals("")) {
                            edtName.setError("Khoản thu không được để trống");
                            edtName.requestFocus();
                            check = false;
                            return;
                        }

                        if (money.equals("")) {
                            edtMoney.setError("Số tiền không được để trống");
                            edtMoney.requestFocus();
                            check = false;
                            return;
                        } else if (!money.equals("")) {
                            try {
                                double so = Double.parseDouble(money);
                                if (so < 0) {
                                    edtMoney.setError("Số tiền phải là số dương");
                                    edtMoney.requestFocus();
                                    check = false;
                                    return;
                                }
                            } catch (Exception e) {
                                edtMoney.setError("Số tiền phải là một số");
                                edtMoney.requestFocus();
                                check = false;
                                return;
                            }
                        }

                        if (ltc.equals("")) {
                            edtLTC.setError("Loại thu không được để trống");
                            edtLTC.requestFocus();
                            check = false;
                            return;
                        } else if (!ltc.equals("")) {
                            LoaiThuChiDAO loaiThuChiDAO = new LoaiThuChiDAO(context);
                            //ktra co ltc ko
                            int finish = loaiThuChiDAO.getAllLTC().size();
                            Log.e("finish: ", finish + "");
                            if (finish == 0) {
                                edtLTC.setError("Loại chi của bạn không tồn tại!\nMời bạn nhập khoản chi sau khi đã nhập loại chi. ");
                                edtLTC.requestFocus();
                                check = false;
                                return;
                            } else {
                                for (int i = 0; i < finish; i++) {
                                    String tenltc = loaiThuChiDAO.getAllLTC().get(i).ltc_ten;
                                    Log.e("tenltc: ", tenltc + "");
                                    if (!ltc.equals(tenltc)) {
                                        edtLTC.setError("Loại chi của bạn không tồn tại!\nMời bạn nhập khoản chi sau khi đã nhập loại chi. ");
                                        edtLTC.requestFocus();
                                        check = false;
                                        return;
                                    }
                                }
                            }
                        }
                        //ktra co ltc ko


                        if (check == true) {
                            ThuChi thuChi = new ThuChi();
                            thuChi.tc_id = (khoanThuDAO.getAllTC().get(position).tc_id);
                            thuChi.tc_ten = name;
                            thuChi.tc_tien = Float.parseFloat(money);
                            thuChi.tc_khoanThuChi = ThuChi.CHI;
                            thuChi.tc_loaiThuChi = ltc;
                            long result = khoanThuDAO.updateTC(thuChi);
                            if (result < 0) {
                                Toast.makeText(context, "cập nhật không thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                alertDialog.dismiss();
                                khoanChiDataList = khoanThuDAO.getAllTC();
                                khoanChiAdapter = new KhoanChiAdapter(context, khoanChiDataList, rvList);
                                //kb layout manager
                                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                                rvList.setLayoutManager(linearLayoutManager);
                                rvList.setAdapter(khoanChiAdapter);
                            }
                        }
                    }
                });
            }
        });
        holder.imgDEL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int result = (int) khoanThuDAO.deleteTC((khoanThuDAO.getAllTC().get(position).tc_id));
                if (result < 0) {
                    Toast.makeText(context, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                } else {
                    khoanChiDataList = khoanThuDAO.getAllTC();
                    khoanChiAdapter = new KhoanChiAdapter(context, khoanChiDataList, rvList);
                    //kb layout manager
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                    rvList.setLayoutManager(linearLayoutManager);
                    rvList.setAdapter(khoanChiAdapter);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return khoanChiDataList.size();
    }
}
