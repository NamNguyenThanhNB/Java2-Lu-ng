package vn.thanhnam.quanlithuchi.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ThuChiSQLite extends SQLiteOpenHelper {
    public ThuChiSQLite(Context context) {
        super(context, "thuchiSQLite01.db", null, 1);
    }

    public static final String tc_id = "id";

    public static final String tc_ten = "ten";

    public static final String tc_tien = "tien";

    public static final String tc_khoanThuChi = "khoanThuChi";

    public static final String tc_loaiThuChi = "loaiThuChi";

    public static final String thuChi_Table = "khoanThuChi";

    public static final String taobangThuChi =
            "Create table khoanThuChi (id integer primary key autoincrement," +
                    "ten NVARCHAR,tien FLOAT,khoanThuChi NVARCHAR," +
                    "loaiThuChi NVARCHAR)";

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(taobangThuChi);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
