package vn.thanhnam.quanlithuchi.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.thanhnam.quanlithuchi.R;
import vn.thanhnam.quanlithuchi.model.LoaiThuChi;
import vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiDAO;

public class LoaiThuAdapter extends RecyclerView.Adapter<LoaiThuHolder> {

    private Context context;
    private List<LoaiThuChi> loaiThuDataList;
    boolean check;
    private RecyclerView rvList;
    private LoaiThuChiDAO loaiThuDAO;
    private LoaiThuAdapter loaiThuAdapter;

    public LoaiThuAdapter(Context context, List<LoaiThuChi> loaiThuDataList, RecyclerView rvList) {
        this.context = context;
        this.loaiThuDataList = loaiThuDataList;
        this.rvList = rvList;
    }

    @NonNull
    @Override
    public LoaiThuHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout._rv, parent, false);
        LoaiThuHolder loaiThuHolder = new LoaiThuHolder(view);
        return loaiThuHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull LoaiThuHolder holder, final int position) {
        loaiThuDAO = new LoaiThuChiDAO(context);
        holder.tvName.setText(loaiThuDAO.getAllLTC().get(position).ltc_ten);
        holder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder_info = new AlertDialog.Builder(context);
                View view_info = LayoutInflater.from(context).inflate(R.layout._infoll, null);
                builder_info.setView(view_info);
                final AlertDialog alertDialog_info = builder_info.show();


                final TextView tvLoai_info = alertDialog_info.findViewById(R.id.tvLoai_infoll);
                final TextView tvName_info = alertDialog_info.findViewById(R.id.tvName_infoll);

                tvName_info.setText(loaiThuDAO.getAllLTC().get(position).ltc_ten);
                tvLoai_info.setText("Loại: " + loaiThuDAO.getAllLTC().get(position).ltc_loaiThuChi);
            }
        });
        holder.imgINS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "UPDATE", Toast.LENGTH_SHORT).show();
                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View viewKT = LayoutInflater.from(context).inflate(R.layout.insert_lt, null);
                builder.setView(viewKT);

                final AlertDialog alertDialog = builder.show();
                final TextView btnNO = alertDialog.findViewById(R.id.btnNO_LT);
                final TextView btnYES = alertDialog.findViewById(R.id.btnYES_LT);

                final EditText edtName = alertDialog.findViewById(R.id.edtName_LT);

                btnNO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });

                btnYES.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        check = true;
                        final String name = edtName.getText().toString().trim();
                        if (name.equals("")) {
                            edtName.setError("Loại thu không được để trống");
                            edtName.requestFocus();
                            check = false;
                            return;
                        }

                        if (check == true) {
                            LoaiThuChi loaiThuChi = new LoaiThuChi();
                            loaiThuChi.ltc_id = ((loaiThuDAO.getAllLTC().get(position).ltc_id));
                            loaiThuChi.ltc_ten = name;
                            loaiThuChi.ltc_loaiThuChi = loaiThuChi.LTHU;
                            long result = loaiThuDAO.updateLTC(loaiThuChi);
                            if (result < 0) {
                                Toast.makeText(context, "cập nhật không thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                alertDialog.dismiss();
                                loaiThuDataList = loaiThuDAO.getAllLTC();
                                loaiThuAdapter = new LoaiThuAdapter(context, loaiThuDataList, rvList);
                                //kb layout manager
                                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                                rvList.setLayoutManager(linearLayoutManager);
                                rvList.setAdapter(loaiThuAdapter);
                            }
                        }
                    }
                });
            }
        });
        holder.imgDEL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int result = (int) loaiThuDAO.deleteLTC((loaiThuDAO.getAllLTC().get(position).ltc_id));
                if (result < 0) {
                    Toast.makeText(context, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                } else {
                    loaiThuDataList = loaiThuDAO.getAllLTC();
                    loaiThuAdapter = new LoaiThuAdapter(context, loaiThuDataList, rvList);
                    //kb layout manager
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                    rvList.setLayoutManager(linearLayoutManager);
                    rvList.setAdapter(loaiThuAdapter);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return loaiThuDataList.size();
    }
}