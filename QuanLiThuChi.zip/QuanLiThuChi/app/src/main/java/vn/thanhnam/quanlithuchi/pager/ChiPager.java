package vn.thanhnam.quanlithuchi.pager;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import vn.thanhnam.quanlithuchi.fragment.KhoanChi_FR;
import vn.thanhnam.quanlithuchi.fragment.KhoanThu_FR;
import vn.thanhnam.quanlithuchi.fragment.LoaiChi_FR;
import vn.thanhnam.quanlithuchi.fragment.LoaiThu_FR;

public class ChiPager extends FragmentStatePagerAdapter {
    public ChiPager(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            KhoanChi_FR khoanChiFragment = new KhoanChi_FR();
            return khoanChiFragment;
        } else {
            LoaiChi_FR loaiChiFragment = new LoaiChi_FR();
            return loaiChiFragment;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return "KHOẢN CHI";
        } else {
            return "LOẠI CHI";
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
}
