package vn.thanhnam.quanlithuchi.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vn.thanhnam.quanlithuchi.R;
import vn.thanhnam.quanlithuchi.adapter.KhoanChiAdapter;
import vn.thanhnam.quanlithuchi.adapter.KhoanThuAdapter;
import vn.thanhnam.quanlithuchi.model.ThuChi;
import vn.thanhnam.quanlithuchi.sqlite.LoaiThuChiDAO;
import vn.thanhnam.quanlithuchi.sqlite.ThuChiDAO;


public class KhoanChi_FR extends Fragment {

    private RecyclerView rvList;
    private ImageView imgDialog;

    private ThuChiDAO thuChiDAO;
    private KhoanChiAdapter khoanChiAdapter;
    private List<ThuChi> thuChiList;
    private LoaiThuChiDAO loaiThuChiDAO;
    private boolean check;
    private int id = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.khoanchi_fr, container, false);
        rvList = root.findViewById(R.id.rvKhoanChi);
        imgDialog = root.findViewById(R.id.imgDialog_KC);
        thuChiDAO = new ThuChiDAO(getActivity());
        thuChiList = thuChiDAO.getAll_TC_CHI();
        khoanChiAdapter = new KhoanChiAdapter(getActivity(), thuChiList, rvList);

        //kb layout manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        rvList.setLayoutManager(linearLayoutManager);
        rvList.setAdapter(khoanChiAdapter);


        imgDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                View viewKT = LayoutInflater.from(getActivity()).inflate(R.layout.insert_kc, null);
                builder.setView(viewKT);

                final AlertDialog alertDialog = builder.show();
                final TextView btnNO = alertDialog.findViewById(R.id.btnNO_KC);
                final TextView btnYES = alertDialog.findViewById(R.id.btnYES_KC);

                final EditText edtName = alertDialog.findViewById(R.id.edtName_KC);
                final EditText edtLTC = alertDialog.findViewById(R.id.edtLTC_KC);
                final EditText edtMoney = alertDialog.findViewById(R.id.edtMoney_KC);


                btnNO.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btnYES.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        check = true;
                        final String name = edtName.getText().toString().trim();
                        final String ltc = edtLTC.getText().toString().trim();
                        final String money = edtMoney.getText().toString().trim();
                        if (name.equals("")) {
                            edtName.setError("Khoản thu không được để trống");
                            edtName.requestFocus();
                            check = false;
                            return;
                        }

                        if (money.equals("")) {
                            edtMoney.setError("Số tiền không được để trống");
                            edtMoney.requestFocus();
                            check = false;
                            return;
                        } else if (!money.equals("")) {
                            try {
                                double so = Double.parseDouble(money);
                                if (so < 0) {
                                    edtMoney.setError("Số tiền phải là số dương");
                                    edtMoney.requestFocus();
                                    check = false;
                                    return;
                                }
                            } catch (Exception e) {
                                edtMoney.setError("Số tiền phải là một số");
                                edtMoney.requestFocus();
                                check = false;
                                return;
                            }
                        }

                        if (ltc.equals("")) {
                            edtLTC.setError("Loại thu không được để trống");
                            edtLTC.requestFocus();
                            check = false;
                            return;
                        } else if (!ltc.equals("")) {
                            loaiThuChiDAO = new LoaiThuChiDAO(getActivity());
                            //ktra co ltc ko
                            int finish = loaiThuChiDAO.getAllLTC().size();
                            if (finish == 0) {
                                edtLTC.setError("Loại thu của bạn không tồn tại!\nMời bạn nhập khoản thu sau khi đã nhập loại thu. ");
                                edtLTC.requestFocus();
                                check = false;
                                return;
                            } else {
                                boolean x = true;
                                for (int i = 0; i < finish; i++) {
                                    String tenltc = loaiThuChiDAO.getAllLTC().get(i).ltc_ten;
                                    if (!ltc.equals(tenltc)) {
                                        x = false;
                                    } else {
                                        x = true;
                                        break;
                                    }
                                }

                                if (x == false) {
                                    edtLTC.setError("Loại thu của bạn không tồn tại!\nMời bạn nhập khoản thu sau khi đã nhập loại thu. ");
                                    edtLTC.requestFocus();
                                    check = false;
                                    return;
                                } else {
                                    check = true;
                                }
                            }
                        }

                        if (check == true) {
                            ThuChi thuChi = new ThuChi();
                            thuChi.tc_id = id;
                            id++;
                            thuChi.tc_ten = name;
                            thuChi.tc_tien = Float.parseFloat(money);
                            thuChi.tc_khoanThuChi = ThuChi.CHI;
                            thuChi.tc_loaiThuChi = ltc;
                            long result = thuChiDAO.insertTC(thuChi);
                            if (result < 0) {
                                Toast.makeText(getActivity(), "cập nhật không thành công", Toast.LENGTH_SHORT).show();
                            } else {
                                alertDialog.dismiss();
                                thuChiList = thuChiDAO.getAll_TC_CHI();
                                khoanChiAdapter = new KhoanChiAdapter(getActivity(), thuChiList, rvList);
                                //kb layout manager
                                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
                                rvList.setLayoutManager(linearLayoutManager);
                                rvList.setAdapter(khoanChiAdapter);
                            }
                        }
                    }
                });
            }
        });
        return root;
    }
}


