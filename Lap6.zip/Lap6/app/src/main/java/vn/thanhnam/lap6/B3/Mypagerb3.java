package vn.thanhnam.lap6.B3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import vn.thanhnam.lap6.R;

public class Mypagerb3 extends Fragment {

    private TextView tvNumber;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pagerb3, container, false);
        tvNumber = view.findViewById(R.id.tvNumber);
        Bundle bundle = getArguments();
        tvNumber.setText(bundle.get("data").toString());
        return view;
    }
}
