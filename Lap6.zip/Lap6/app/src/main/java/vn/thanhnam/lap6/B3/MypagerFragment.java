package vn.thanhnam.lap6.B3;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import vn.thanhnam.lap6.B2.MyFragmentRightb2;

public class MypagerFragment extends FragmentStatePagerAdapter {
    public MypagerFragment(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        Bundle bundle = new Bundle();
        bundle.putInt("data", position);
        Mypagerb3 mypagerb3 = new Mypagerb3();
        mypagerb3.setArguments(bundle);
        return mypagerb3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return "TAB " + position;
    }

    @Override
    public int getCount() {
        return 3;
    }
}
