package vn.thanhnam.lap6.B3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import vn.thanhnam.lap6.R;

public class ACTbai3 extends AppCompatActivity {
    private ViewPager pager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai3);
        pager = findViewById(R.id.pager);
        tabLayout = findViewById(R.id.tabs);

        MypagerFragment mypagerFragment = new MypagerFragment(getSupportFragmentManager());
        pager.setAdapter(mypagerFragment);
        tabLayout.setupWithViewPager(pager);
    }
}
