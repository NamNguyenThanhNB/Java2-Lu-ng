package vn.thanhnam.lap6.B2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import vn.thanhnam.lap6.R;

public class MyFragmentRightb2 extends Fragment {

    private TextView tvText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragmentb2r, container, false);
        tvText = view.findViewById(R.id.tvText);
        return view;
    }
}
