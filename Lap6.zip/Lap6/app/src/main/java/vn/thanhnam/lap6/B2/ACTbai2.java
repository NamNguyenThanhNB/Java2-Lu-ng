package vn.thanhnam.lap6.B2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import vn.thanhnam.lap6.R;

public class ACTbai2 extends AppCompatActivity {
    private Button btnok;
    private EditText edtok;
    private TextView tvText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai2);
        btnok = findViewById(R.id.btnok);
        edtok = findViewById(R.id.edtok);
        tvText = findViewById(R.id.tvText);

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String text = edtok.getText().toString();
                Log.e("kdasdasdak", text);
                tvText.setText(text);
            }
        });
    }
}
