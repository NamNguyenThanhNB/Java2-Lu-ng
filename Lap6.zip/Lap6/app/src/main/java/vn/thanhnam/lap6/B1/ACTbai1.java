package vn.thanhnam.lap6.B1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import vn.thanhnam.lap6.R;

public class ACTbai1 extends AppCompatActivity {
    private Button btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actbai1);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);

        final FragmentManager fragmentManager = getSupportFragmentManager();
        final MyFragmentRight1 myFragmentRight1 = new MyFragmentRight1();
        fragmentManager.beginTransaction().add(R.id.frb1, myFragmentRight1).commit();
        final MyFragmentRight2 myFragmentRight2 = new MyFragmentRight2();
        fragmentManager.beginTransaction().add(R.id.frb1, myFragmentRight2).commit();
        fragmentManager.beginTransaction().hide(myFragmentRight1).commit();
        fragmentManager.beginTransaction().hide(myFragmentRight2).commit();
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentManager.beginTransaction().show(myFragmentRight1).commit();
                fragmentManager.beginTransaction().hide(myFragmentRight2).commit();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentManager.beginTransaction().hide(myFragmentRight1).commit();
                fragmentManager.beginTransaction().show(myFragmentRight2).commit();
            }
        });
    }
}
