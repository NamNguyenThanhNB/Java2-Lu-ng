package vn.thanhnam.demo03.Adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import vn.thanhnam.demo03.R;

class FoodHolder extends RecyclerView.ViewHolder {

    public TextView tvId, tvName, tvPrice;

    public FoodHolder(@NonNull View itemView) {
        super(itemView);

        tvId = itemView.findViewById(R.id.tvId);
        tvName = itemView.findViewById(R.id.tvName);
        tvPrice = itemView.findViewById(R.id.tvPrice);
    }
}
