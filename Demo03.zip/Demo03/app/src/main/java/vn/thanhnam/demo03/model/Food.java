package vn.thanhnam.demo03.model;

public class Food {

    public String id;
    public String name;
    public String price;
}
