package vn.thanhnam.demo03.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import vn.thanhnam.demo03.Adapter.FoodAdapter;
import vn.thanhnam.demo03.R;
import vn.thanhnam.demo03.model.Food;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvList = findViewById(R.id.rvList);
        List<Food> foodList = new ArrayList<>();

        for (int i = 0; i < 20; i++) {
            Food food = new Food();
            food.id = "123nam" + i;
            food.name = "Nguyen Thanh Nam";
            food.price = "20,000đ";

            foodList.add(food);
        }

        FoodAdapter foodAdapter = new FoodAdapter(foodList, MainActivity.this);


        //hien thi

        //chieu doc
        LinearLayoutManager vertical = new LinearLayoutManager(this);
        //chieu  ngang
        LinearLayoutManager horizontal = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        //dang luoi so le
        StaggeredGridLayoutManager gridLayoutManager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);

        rvList.setAdapter(foodAdapter);
        rvList.setLayoutManager(gridLayoutManager);
    }
}
