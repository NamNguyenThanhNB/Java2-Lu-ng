package vn.thanhnam.demo03.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.opengl.EGLExt;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import vn.thanhnam.demo03.R;

public class AutoActivity extends AppCompatActivity {
    private AutoCompleteTextView autoCompleteTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto);
        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);

        String food[] = {"Chicken", "Bef", "Fruit", "Orange", "Lemon", "Apple", "Cherry", "StrawBerry",
                "Bean", "Snack", "Potato", "Sweet Potato", "Soup", "Tofu", "Mango", "Fish", "Vegetable"};

        ArrayAdapter<String> foodAdapter = new ArrayAdapter<>(this, android.R.layout.select_dialog_item, food);

        autoCompleteTextView.setAdapter(foodAdapter);
    }
}
