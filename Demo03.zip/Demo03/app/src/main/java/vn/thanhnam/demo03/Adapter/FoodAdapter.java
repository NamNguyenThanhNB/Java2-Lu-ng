package vn.thanhnam.demo03.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.thanhnam.demo03.R;
import vn.thanhnam.demo03.model.Food;

public class FoodAdapter extends RecyclerView.Adapter<FoodHolder> {
    private List<Food> foodList;
    private Context context;

    public FoodAdapter(List<Food> foodList, Context context) {
        this.foodList = foodList;
        this.context = context;
    }

    @NonNull
    @Override //tao adapter
    public FoodHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.food, parent, false);

        FoodHolder foodHolder = new FoodHolder(view);
        return foodHolder;
    }

    @Override//gan du lieu vao adapter
    public void onBindViewHolder(@NonNull final FoodHolder holder, int position) {
        Food food = foodList.get(position);

        holder.tvId.setText(food.id);
        holder.tvName.setText(food.name);
        holder.tvPrice.setText(food.price);

        holder.tvId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "" + holder.tvId.getText(), Toast.LENGTH_SHORT).show();
            }
        });


        holder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "" + holder.tvName.getText(), Toast.LENGTH_SHORT).show();
            }
        });


        holder.tvPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "" + holder.tvPrice.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Ha lo :3", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }
}
