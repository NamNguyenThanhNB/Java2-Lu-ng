﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Players : MonoBehaviour
{


    public float speed = 50f, maxspeed = 5, jumpPow = 220f;

    public bool grounded = true, faceright = true, jumpcheck = false;


    public Rigidbody2D r2;
    public Animator anim;
    // Start is called before the first frame update
    void Start()
    {

        r2 = gameObject.GetComponent<Rigidbody2D>();

        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        anim.SetBool("Grounded", grounded);
        anim.SetFloat("Speed", Mathf.Abs(r2.velocity.x));

        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
        {
            if (grounded)
            {
                grounded = false;
                r2.AddForce(Vector2.up * jumpPow);
                jumpcheck = true;
            }
        }


        if (grounded == false && jumpcheck)
        {
            grounded = true;
            jumpcheck = false;
        }

    }

    void FixedUpdate()
    {
        // làm nhân vật di chuyển
        float h = Input.GetAxis("Horizontal");
        r2.AddForce((Vector2.right) * speed * h);

        // giới hạn tốc độ
        if (r2.velocity.x > maxspeed)
            r2.velocity = new Vector2(maxspeed, r2.velocity.y);
        if (r2.velocity.x < -maxspeed)
            r2.velocity = new Vector2(-maxspeed, r2.velocity.y);
        if (h > 0 && !faceright)
        {
            Flip();
        }

        if (h < 0 && faceright)
        {
            Flip();
        }

    }

    public void Flip()
    {
        faceright = !faceright;
        Vector3 Scale;
        Scale = transform.localScale;
        Scale.x *= -1;
        transform.localScale = Scale;
    }
}
