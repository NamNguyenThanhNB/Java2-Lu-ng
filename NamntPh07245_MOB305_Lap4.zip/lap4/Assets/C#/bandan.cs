﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bandan : MonoBehaviour
{
    public Players players;
    public float speed, timetoDestroy;
    public Rigidbody2D r2;
    public Animator anim;
    // Start is called before the first frame update
    void Start()
    {

        players = gameObject.GetComponent<Players>();
        r2 = gameObject.GetComponent<Rigidbody2D>();
        Destroy(gameObject,timetoDestroy);
    }

    // Update is called once per frame
    void Update()
    {
            r2.velocity = Vector2.right * speed;
    }
}
