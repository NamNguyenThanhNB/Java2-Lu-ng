﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundedCheck : MonoBehaviour
{
    public Players players;
    // Start is called before the first frame update
    void Start()
    {
        players = gameObject.GetComponent<Players>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    // khi va chạm
    private void OnTriggerEnter2D(Collider2D collision)
    {
        players.grounded = true;
    }

    // vẫn trong va chạm
    private void OnTriggerStay2D(Collider2D collision)
    {
        players.grounded = true;
    }

    //thoát va chạm
    private void OnTriggerExit2D(Collider2D collision)
    {
        players.grounded = false;
    }
}
