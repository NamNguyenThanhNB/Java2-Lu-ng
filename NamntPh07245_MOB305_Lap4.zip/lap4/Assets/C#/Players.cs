﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Players : MonoBehaviour
{


    public float speed = 50f, maxspeed = 5, jumpPow = 220f;

    public bool grounded = true, faceright = true, doublejump = false, ck=false;

    public GameObject bandan;
    public Transform diemban;
    public Rigidbody2D r2;
    public Animator anim;

    public float x=0;
    // Start is called before the first frame update
    void Start()
    {

        r2 = gameObject.GetComponent<Rigidbody2D>();

        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        // gán giá trị cho Grounded và Speed trong animation
        anim.SetBool("Grounded", grounded);
        anim.SetFloat("Speed", Mathf.Abs(r2.velocity.x));

        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
        {
            if (grounded)
            {
                grounded = false;
                doublejump = true;
                r2.AddForce(Vector2.up * jumpPow);

            }
            else
            {
                //nhảy 2 lần
                if (doublejump)
                {
                    doublejump = false;
                    r2.velocity = new Vector2(r2.velocity.x, 0);
                    r2.AddForce(Vector2.up * jumpPow * 0.7f);
                }
            }

        }

        //bắn đạn
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.KeypadEnter))
        {
            anim.SetInteger("shoot", 1);
            Ban();
            ck = true;
        }
       
    }

    void FixedUpdate()
    {
        // làm nhân vật di chuyển
        float h = Input.GetAxis("Horizontal");
        x = h;
        r2.AddForce((Vector2.right) * speed * h);

        // giới hạn tốc độ
        if (r2.velocity.x > maxspeed)
            r2.velocity = new Vector2(maxspeed, r2.velocity.y);
        if (r2.velocity.x < -maxspeed)
            r2.velocity = new Vector2(-maxspeed, r2.velocity.y);
        if (h > 0 && !faceright)
        {
            Flip();
        }

        if (h < 0 && faceright)
        {
            Flip();
        }

        if (ck)
        {

            anim.SetInteger("shoot", 0);
            ck = false;
        }

        //tạo lực ma sát
        if (grounded)
        {
            r2.velocity = new Vector2(r2.velocity.x * 0.7f, r2.velocity.y);
        }
    }

    //xoay chiều khi quay trái phải
    public void Flip()
    {
        faceright = !faceright;
        Vector3 Scale;
        Scale = transform.localScale;
        Scale.x *= -1;
        transform.localScale = Scale;
    }

    void Ban()
    {
        if(bandan && diemban)
        {
            Instantiate(bandan, diemban.position, Quaternion.identity);
        }
    }
}
