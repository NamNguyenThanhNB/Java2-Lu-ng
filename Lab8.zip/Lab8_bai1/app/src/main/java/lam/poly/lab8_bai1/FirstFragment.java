package lam.poly.lab8_bai1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import java.util.ArrayList;
import java.util.List;

public class FirstFragment extends Fragment {
    public FirstFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        List<Muc> mucList = new ArrayList<>();
        int anh[] = {R.drawable.frenchi, R.drawable.tsuzu, R.drawable.huongtram, R.drawable.sunset};


        mucList.add(new Muc(anh[0], "Chó Bulldog Pháp"));
        mucList.add(new Muc(anh[1], "Tsuzu nhóm Twice"));
        mucList.add(new Muc(anh[2], "Hương Tràm đi du học Mỹ"));
        mucList.add(new Muc(anh[3], "Thiên nhiên tuyệt đẹp"));

        RecyclerView recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        MyAdapter myAdapter = new MyAdapter(mucList);
        recyclerView.setAdapter(myAdapter);

        return view;
    }

}
