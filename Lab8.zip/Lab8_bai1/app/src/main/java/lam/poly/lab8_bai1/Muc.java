package lam.poly.lab8_bai1;

public class Muc {
    int hinh;
    String chuoi;

    public Muc(int hinh, String chuoi) {
        this.hinh = hinh;
        this.chuoi = chuoi;
    }
}
